import sys
# sys.stdout = open("d:\\goat.txt", "w")
def sorting(List):
    swapped = True
    n = len(List)
    print(n,range(0,n-1))
    # while (swapped == True):
        
    #     print(n)
    #     for i in range(0,n-1):
    #         swapped = False
            
    #         if(List[i] > List[i+1]):
    #             temp = List[i]
    #             List[i] = List[i+1]
    #             List[i+1] = temp
    #             swapped = True
    #         print(swapped,n)
    #     n = n-1
    print(List)

sorting(["zahbfgyrbvnq","khbvyugaygr"])
